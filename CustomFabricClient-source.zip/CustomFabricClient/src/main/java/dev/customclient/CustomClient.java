package dev.customclient;

import dev.customclient.config.ClientConfig;
import dev.customclient.gui.ClickGuiScreen;
import dev.customclient.hud.HudRenderer;
import dev.customclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class CustomClient implements ClientModInitializer {
    public static final String MOD_ID = "customclient";
    public static KeyBinding openGuiKey;
    public static final ModuleManager MODULES = new ModuleManager();

    @Override
    public void onInitializeClient() {
        ClientConfig.load();
        MODULES.registerDefaults();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.customclient.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
            "key.categories.customclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen instanceof ClickGuiScreen) client.setScreen(null);
                else if (client.player != null && client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            MODULES.tick(client);
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> HudRenderer.render(drawContext));
    }
}
