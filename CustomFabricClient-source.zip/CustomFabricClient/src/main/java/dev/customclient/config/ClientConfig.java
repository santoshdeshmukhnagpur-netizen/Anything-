package dev.customclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = Path.of("config", "customclient.json");
    public static Data data = new Data();

    private ClientConfig() {}

    public static final class Data {
        public int accentColor = 0xFF8B5CF6;
        public String selectedCategory = "VISUALS";
        public double maxPlayerRange = 64.0;
        public Map<String, Boolean> modules = new HashMap<>();
    }

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                data = GSON.fromJson(Files.readString(PATH), Data.class);
            }
        } catch (Exception e) {
            data = new Data();
        }
        if (data == null) data = new Data();
        if (data.modules == null) data.modules = new HashMap<>();
        if (data.selectedCategory == null) data.selectedCategory = "VISUALS";
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(data));
        } catch (IOException e) {
            System.err.println("[CustomClient] Config save failed: " + e.getMessage());
        }
    }
}
