package dev.customclient.hud;

import dev.customclient.CustomClient;
import dev.customclient.config.ClientConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;

public final class HudRenderer {
    private static long lastTime = System.currentTimeMillis();
    private static int frames, fps;

    private HudRenderer() {}

    public static void render(DrawContext ctx) {
        // FPS is measured by counting HUD frames per second.
        frames++;
        long now = System.currentTimeMillis();
        if (now - lastTime >= 1000) { fps = frames; frames = 0; lastTime = now; }

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (!CustomClient.MODULES.isEnabled("HUD")) return;

        List<String> lines = new ArrayList<>();
        if (CustomClient.MODULES.isEnabled("FPS Counter")) lines.add("FPS: " + fps);
        if (CustomClient.MODULES.isEnabled("Coordinates")) {
            lines.add(String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        if (CustomClient.MODULES.isEnabled("Performance Hints") && fps > 0 && fps < 60) {
            int view = mc.options.getViewDistance().getValue();
            if (view > 12) lines.add("Hint: lower render distance (" + view + ")");
            else lines.add("Hint: lower graphics settings or close other apps");
        }
        if (CustomClient.MODULES.isEnabled("Nearby Players")) {
            List<PlayerEntity> near = new ArrayList<>();
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p != mc.player && mc.player.distanceTo(p) <= ClientConfig.data.maxPlayerRange) near.add(p);
            }
            near.sort((a, b) -> Float.compare(mc.player.distanceTo(a), mc.player.distanceTo(b)));
            if (!near.isEmpty()) lines.add("Players nearby:");
            for (int i = 0; i < Math.min(8, near.size()); i++) {
                PlayerEntity p = near.get(i);
                lines.add(String.format(Locale.ROOT, "  %s  %.0fm", p.getName().getString(), mc.player.distanceTo(p)));
            }
        }
        if (lines.isEmpty()) return;

        TextRenderer tr = mc.textRenderer;
        int width = 0;
        for (String s : lines) width = Math.max(width, tr.getWidth(s));
        int x = 6, y = 6;
        ctx.fill(x - 3, y - 3, x + width + 4, y + lines.size() * 11 + 1, 0x90000000);
        ctx.fill(x - 3, y - 3, x - 1, y + lines.size() * 11 + 1, ClientConfig.data.accentColor);
        for (String s : lines) {
            ctx.drawTextWithShadow(tr, s, x + 2, y, 0xFFFFFFFF);
            y += 11;
        }
    }
}
