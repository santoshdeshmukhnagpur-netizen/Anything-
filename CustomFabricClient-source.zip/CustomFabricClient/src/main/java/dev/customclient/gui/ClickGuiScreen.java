package dev.customclient.gui;

import dev.customclient.CustomClient;
import dev.customclient.config.ClientConfig;
import dev.customclient.module.ClientModule;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiScreen extends Screen {
    private int panelX = 24, panelY = 28;
    private boolean dragging;
    private double dragX, dragY;
    private ClientModule.Category category;
    private String search = "";

    public ClickGuiScreen() {
        super(Text.literal("Custom Client"));
        try { category = ClientModule.Category.valueOf(ClientConfig.data.selectedCategory.toUpperCase()); }
        catch (Exception ignored) { category = ClientModule.Category.VISUALS; }
    }

    private int panelW() { return Math.min(520, width - 24); }
    private int panelH() { return Math.min(340, height - 24); }

    private List<ClientModule> visible() {
        List<ClientModule> out = new ArrayList<>();
        String q = search.toLowerCase();
        for (ClientModule m : CustomClient.MODULES.all()) {
            if (q.isEmpty() ? m.category() == category : m.name().toLowerCase().contains(q)) out.add(m);
        }
        return out;
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta); // draws the vanilla background once
        int w = panelW(), h = panelH();
        panelX = Math.max(8, Math.min(panelX, width - w - 8));
        panelY = Math.max(8, Math.min(panelY, height - h - 8));
        int accent = ClientConfig.data.accentColor;

        ctx.fill(panelX, panelY, panelX + w, panelY + h, 0xF0181922);
        ctx.fill(panelX, panelY, panelX + w, panelY + 34, 0xFF242532);
        ctx.fill(panelX, panelY, panelX + 4, panelY + h, accent);
        ctx.drawText(textRenderer, "CUSTOM CLIENT", panelX + 16, panelY + 12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, "Right Shift / ESC", panelX + w - 115, panelY + 12, 0xFFB7B8C8, false);

        int cy = panelY + 48;
        for (ClientModule.Category c : ClientModule.Category.values()) {
            int bx = panelX + 12 + c.ordinal() * 82;
            if (bx + 78 > panelX + w - 8) break;
            boolean active = search.isEmpty() && c == category;
            ctx.fill(bx, cy, bx + 76, cy + 22, active ? accent : 0xFF2A2B38);
            ctx.drawCenteredTextWithShadow(textRenderer, title(c), bx + 38, cy + 7, 0xFFFFFFFF);
        }

        long blink = (System.currentTimeMillis() / 500) % 2;
        String hint = search.isEmpty() ? "Type to search modules..." : "Search: " + search + (blink == 0 ? "_" : "");
        ctx.drawText(textRenderer, hint, panelX + 16, panelY + 80, 0xFFB7B8C8, false);

        int y = panelY + 100;
        List<ClientModule> mods = visible();
        if (mods.isEmpty()) {
            ctx.drawText(textRenderer, "No modules here yet.", panelX + 22, y + 8, 0xFF8A8B9C, false);
        }
        for (ClientModule module : mods) {
            ctx.fill(panelX + 12, y, panelX + w - 12, y + 34, module.enabled() ? 0xFF33304A : 0xFF23242F);
            ctx.fill(panelX + w - 43, y + 10, panelX + w - 25, y + 24, module.enabled() ? accent : 0xFF555665);
            ctx.drawText(textRenderer, module.name(), panelX + 22, y + 7, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, module.description(), panelX + 22, y + 19, 0xFFB7B8C8, false);
            y += 40;
            if (y > panelY + h - 34) break;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int w = panelW();
        if (mouseY >= panelY && mouseY <= panelY + 34) {
            dragging = true; dragX = mouseX - panelX; dragY = mouseY - panelY; return true;
        }
        if (mouseY >= panelY + 48 && mouseY <= panelY + 70) {
            for (ClientModule.Category c : ClientModule.Category.values()) {
                int bx = panelX + 12 + c.ordinal() * 82;
                if (bx + 78 > panelX + w - 8) break;
                if (mouseX >= bx && mouseX <= bx + 76) {
                    category = c; search = "";
                    ClientConfig.data.selectedCategory = c.name();
                    ClientConfig.save();
                    return true;
                }
            }
        }
        int y = panelY + 100;
        for (ClientModule module : visible()) {
            if (mouseY >= y && mouseY <= y + 34 && mouseX >= panelX + 12 && mouseX <= panelX + w - 12) {
                module.toggle();
                CustomClient.MODULES.saveStates();
                return true;
            }
            y += 40;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging) { panelX = (int) (mouseX - dragX); panelY = (int) (mouseY - dragY); return true; }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1); return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (chr >= 32 && chr != 127 && search.length() < 24) { search += chr; return true; }
        return super.charTyped(chr, modifiers);
    }

    private static String title(ClientModule.Category c) {
        String s = c.name().toLowerCase();
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
