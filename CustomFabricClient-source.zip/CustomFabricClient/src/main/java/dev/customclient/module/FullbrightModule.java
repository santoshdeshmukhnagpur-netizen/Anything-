package dev.customclient.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side brightness boost using a hidden, locally applied Night Vision effect. */
public final class FullbrightModule extends ClientModule {
    private boolean applied;

    public FullbrightModule() {
        super("Fullbright", "Brightens the scene (local Night Vision effect).", Category.VISUALS, false);
    }

    @Override
    public void tick(MinecraftClient client) {
        if (client.player == null) return;
        StatusEffectInstance current = client.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || current.getDuration() < 230) {
            client.player.addStatusEffect(
                new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            applied = true;
        }
    }

    @Override
    protected void onDisable(MinecraftClient client) {
        if (applied && client.player != null) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        applied = false;
    }
}
