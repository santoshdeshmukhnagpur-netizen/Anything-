package dev.customclient.module;

import dev.customclient.config.ClientConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public final class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<>();

    public void registerDefaults() {
        modules.clear();
        modules.add(new ClientModule("HUD", "Master switch for the on-screen overlay.", ClientModule.Category.UTILITY, true));
        modules.add(new ClientModule("Coordinates", "Show your current position.", ClientModule.Category.UTILITY, true));
        modules.add(new ClientModule("FPS Counter", "Show current frames per second.", ClientModule.Category.PERFORMANCE, true));
        modules.add(new ClientModule("Performance Hints", "Show tips when FPS is low.", ClientModule.Category.PERFORMANCE, false));
        modules.add(new ClientModule("Nearby Players", "List visible players in range with distance.", ClientModule.Category.VISUALS, false));
        modules.add(new FullbrightModule());

        for (ClientModule m : modules) {
            Boolean saved = ClientConfig.data.modules.get(m.name());
            m.setEnabled(saved != null ? saved : m.defaultEnabled());
        }
    }

    public List<ClientModule> all() { return Collections.unmodifiableList(modules); }

    public List<ClientModule> inCategory(ClientModule.Category category) {
        return modules.stream().filter(m -> m.category() == category).toList();
    }

    public ClientModule find(String name) {
        return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    public boolean isEnabled(String name) {
        ClientModule m = find(name);
        return m != null && m.enabled();
    }

    public void saveStates() {
        for (ClientModule m : modules) ClientConfig.data.modules.put(m.name(), m.enabled());
        ClientConfig.save();
    }

    public void tick(MinecraftClient client) {
        for (ClientModule module : modules) if (module.enabled()) module.tick(client);
    }
}
