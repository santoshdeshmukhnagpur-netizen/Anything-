package dev.customclient.module;

import net.minecraft.client.MinecraftClient;

public class ClientModule {
    public enum Category { COMBAT, VISUALS, MOVEMENT, UTILITY, PERFORMANCE, SETTINGS }

    private final String name, description;
    private final Category category;
    private final boolean defaultEnabled;
    private boolean enabled;

    public ClientModule(String name, String description, Category category, boolean defaultEnabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.defaultEnabled = defaultEnabled;
    }

    public String name() { return name; }
    public String description() { return description; }
    public Category category() { return category; }
    public boolean defaultEnabled() { return defaultEnabled; }
    public boolean enabled() { return enabled; }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        MinecraftClient client = MinecraftClient.getInstance();
        if (value) onEnable(client); else onDisable(client);
    }

    public void toggle() { setEnabled(!enabled); }

    protected void onEnable(MinecraftClient client) {}
    protected void onDisable(MinecraftClient client) {}
    public void tick(MinecraftClient client) {}
}
