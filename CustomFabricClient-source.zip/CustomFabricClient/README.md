# Custom Fabric Client (Minecraft 1.21.4, Fabric)

Client-side mod with a dark Click GUI (Right Shift), draggable panel, category tabs,
module search, and JSON config persistence (`config/customclient.json`).

## Working features
- Click GUI: open/close with Right Shift (rebindable in Controls), drag by the title bar, search by typing.
- HUD (master switch), FPS Counter, Coordinates.
- Performance Hints: tips shown when FPS drops below 60.
- Nearby Players: on-screen list of players the client can see, with distance.
- Fullbright: local Night Vision effect, removed when toggled off.
- Module on/off states are saved and restored.

## Not included
Player/Ore ESP world rendering (outlines/boxes through walls) is not implemented.

## Build
Needs JDK 21 and internet access.

    gradle build        # Gradle 8.11+ (8.12 recommended)

The mod jar is `build/libs/custom-fabric-client-1.0.0.jar` (not the `-sources` jar).
Alternatively, push this folder to GitHub: the included workflow builds it and
attaches the jar as a downloadable artifact.

## Install
Put the jar and Fabric API (1.21.4) in your `mods` folder with Fabric Loader >= 0.16.0.

Note: written without being compiled in the authoring environment; if Gradle reports a
mapping/API difference, fix that line and rebuild.
