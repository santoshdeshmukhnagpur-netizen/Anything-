# Custom Fabric Client (Minecraft 1.21.4)

A client-side Fabric mod project with a dark Click GUI, category navigation, module toggles, Right Shift opening, draggable panel, and JSON configuration persistence.

## Build
Requires JDK 21. From this directory run:

```sh
gradle build
```

The resulting jar is in `build/libs/`.

## Current implementation status
- Project metadata and Fabric entrypoint are included.
- Click GUI and module registry are implemented as a starter foundation.
- Config is persisted to `config/customclient.json`.
- The visual module entries are registered, but **Player ESP, Ore ESP, Fullbright, HUD drawing, FPS/coordinates rendering, animations, search input, and editable keybinds still need their renderer/config implementations**. The module registry is not a claim that these visual effects are already functional.
- The code has not been compiled in this environment because Gradle is not installed and dependency downloads are not available here. Run `gradle build` in a Java 21 + network-enabled environment and fix any API-version differences reported by Loom.
- ESP should be used only for information legitimately available to the client or in private testing worlds; this project does not attempt to bypass server-side visibility or anti-cheat.
