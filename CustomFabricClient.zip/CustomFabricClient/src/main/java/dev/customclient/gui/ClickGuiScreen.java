package dev.customclient.gui;

import dev.customclient.CustomClient;
import dev.customclient.config.ClientConfig;
import dev.customclient.module.ClientModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiScreen extends Screen {
    private int panelX = 24, panelY = 28;
    private boolean dragging;
    private double dragX, dragY;
    private ClientModule.Category category;
    private String search = "";

    public ClickGuiScreen() {
        super(Text.literal("Custom Client"));
        try { category = ClientModule.Category.valueOf(ClientConfig.data.selectedCategory.toUpperCase()); }
        catch (Exception ignored) { category = ClientModule.Category.VISUALS; }
    }
    @Override public boolean shouldPause() { return false; }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int w = Math.min(520, width - 24), h = Math.min(340, height - 24);
        panelX = Math.max(8, Math.min(panelX, width - w - 8));
        panelY = Math.max(8, Math.min(panelY, height - h - 8));
        ctx.fill(panelX, panelY, panelX+w, panelY+h, 0xF0181922);
        ctx.fill(panelX, panelY, panelX+w, panelY+34, 0xFF242532);
        ctx.fill(panelX, panelY, panelX+4, panelY+h, ClientConfig.data.accentColor);
        ctx.drawText(textRenderer, "CUSTOM CLIENT", panelX+16, panelY+12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, "Right Shift / ESC", panelX+w-115, panelY+12, 0xFFB7B8C8, false);

        int cy = panelY + 48;
        for (ClientModule.Category c : ClientModule.Category.values()) {
            String label = title(c);
            int bx = panelX + 12 + c.ordinal()*82;
            if (bx + 78 > panelX+w-8) break;
            ctx.fill(bx, cy, bx+76, cy+22, c == category ? ClientConfig.data.accentColor : 0xFF2A2B38);
            ctx.drawCenteredTextWithShadow(textRenderer, label, bx+38, cy+7, 0xFFFFFFFF);
        }
        ctx.drawText(textRenderer, "Click a module to toggle it", panelX+16, panelY+80, 0xFFB7B8C8, false);
        int y = panelY+100;
        for (ClientModule module : CustomClient.MODULES.inCategory(category)) {
            if (!module.name().toLowerCase().contains(search.toLowerCase())) continue;
            ctx.fill(panelX+12, y, panelX+w-12, y+34, module.enabled()?0xFF33304A:0xFF23242F);
            ctx.fill(panelX+w-43, y+10, panelX+w-25, y+24, module.enabled()?ClientConfig.data.accentColor:0xFF555665);
            ctx.drawText(textRenderer, module.name(), panelX+22, y+7, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, module.description(), panelX+22, y+19, 0xFFB7B8C8, false);
            y += 40;
            if (y > panelY+h-24) break;
        }
        super.render(ctx, mouseX, mouseY, delta);
    }
    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int w = Math.min(520, width-24);
        if (mouseY >= panelY && mouseY <= panelY+34) {
            dragging = true; dragX = mouseX-panelX; dragY = mouseY-panelY; return true;
        }
        if (mouseY >= panelY+48 && mouseY <= panelY+70) {
            for (ClientModule.Category c : ClientModule.Category.values()) {
                int bx = panelX+12+c.ordinal()*82;
                if (mouseX >= bx && mouseX <= bx+76) {
                    category=c; ClientConfig.data.selectedCategory=category.name(); ClientConfig.save(); return true;
                }
            }
        }
        int y = panelY+100;
        for (ClientModule module : CustomClient.MODULES.inCategory(category)) {
            if (mouseY >= y && mouseY <= y+34 && mouseX >= panelX+12 && mouseX <= panelX+w-12) {
                module.toggle();
                if (module.name().equals("HUD")) ClientConfig.data.hudEnabled=module.enabled();
                if (module.name().equals("Fullbright")) ClientConfig.data.fullbright=module.enabled();
                ClientConfig.save(); return true;
            }
            y += 40;
        }
        return true;
    }
    @Override public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging) { panelX=(int)(mouseX-dragX); panelY=(int)(mouseY-dragY); return true; }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }
    @Override public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging=false; return super.mouseReleased(mouseX, mouseY, button);
    }
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    private static String title(ClientModule.Category c) {
        String s=c.name().toLowerCase(); return Character.toUpperCase(s.charAt(0))+s.substring(1);
    }
}
