package dev.customclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = Path.of("config", "customclient.json");
    public static Data data = new Data();
    private ClientConfig() {}
    public static final class Data {
        public int accentColor = 0xFF8B5CF6;
        public String selectedCategory = "Visuals";
        public boolean hudEnabled = true;
        public boolean fps = true;
        public boolean coordinates = true;
        public boolean fullbright = false;
        public boolean playerEsp = false;
        public boolean playerNames = true;
        public boolean playerDistance = true;
        public double maxEspDistance = 64.0;
        public boolean oreEsp = false;
        public double oreRange = 24.0;
    }
    public static void load() {
        try {
            if (Files.exists(PATH)) data = GSON.fromJson(Files.readString(PATH), Data.class);
        } catch (Exception ignored) { data = new Data(); }
        if (data == null) data = new Data();
    }
    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(data));
        } catch (IOException e) { System.err.println("[CustomClient] Config save failed: " + e.getMessage()); }
    }
}
