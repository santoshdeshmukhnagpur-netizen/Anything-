package dev.customclient.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;

public final class ModuleManager {
    private final List<ClientModule> modules = new ArrayList<>();
    public void registerDefaults() {
        modules.clear();
        modules.add(new ClientModule("Player ESP", "Highlight entities currently known to the client.", ClientModule.Category.VISUALS));
        modules.add(new ClientModule("Ore ESP", "Highlight selected blocks in loaded client chunks.", ClientModule.Category.VISUALS));
        modules.add(new ClientModule("Fullbright", "Increase local scene brightness.", ClientModule.Category.VISUALS));
        modules.add(new ClientModule("HUD", "Toggle the client information overlay.", ClientModule.Category.UTILITY));
        modules.add(new ClientModule("FPS Counter", "Show current frames per second.", ClientModule.Category.PERFORMANCE));
        modules.add(new ClientModule("Coordinates", "Show your current position.", ClientModule.Category.UTILITY));
        modules.add(new ClientModule("Performance Hints", "Display lightweight client performance guidance.", ClientModule.Category.PERFORMANCE));
    }
    public List<ClientModule> all() { return Collections.unmodifiableList(modules); }
    public List<ClientModule> inCategory(ClientModule.Category category) {
        return modules.stream().filter(m -> m.category() == category).toList();
    }
    public ClientModule find(String name) {
        return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    public void tick(MinecraftClient client) {
        for (ClientModule module : modules) if (module.enabled()) module.tick(client);
    }
}
