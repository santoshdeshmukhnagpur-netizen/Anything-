package dev.customclient.module;

import net.minecraft.client.MinecraftClient;

public final class ClientModule {
    public enum Category { COMBAT, VISUALS, MOVEMENT, UTILITY, PERFORMANCE, SETTINGS }
    private final String name, description;
    private final Category category;
    private boolean enabled;
    public ClientModule(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }
    public String name() { return name; }
    public String description() { return description; }
    public Category category() { return category; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean value) { enabled = value; }
    public void toggle() { enabled = !enabled; }
    public void tick(MinecraftClient client) {}
}
